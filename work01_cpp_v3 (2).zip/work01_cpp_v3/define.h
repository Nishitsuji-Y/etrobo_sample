#define TRACE 0
#define STRAIGHT 1
#define TURNLEFT 2
#define STOP 3

#define STATE0_DISTANCE 3650
// #define STATE1_DISTANCE 750
// #define STATE2_DISTANCE 900
// #define STATE3_DISTANCE 1500
// #define STATE4_DISTANCE 1750
// #define STATE5_DISTANCE 2250
// #define STATE6_DISTANCE 2550
// #define STATE7_DISTANCE 3050
// #define STATE8_DISTANCE 3200
#define STATE10_DISTANCE 3850
#define motorDivide 6

#define TIRE_DIAMETER 100 //mm
#define TREAD_DIAMETER 150 //mm
#define PI 3.1415 
