#include "Motor.h"
#include "define.h"

using namespace ev3api;

class Turn {
    public:
        Turn();
        void rotateLeft();
        void rotateRight();
        
    private:
        Motor leftWheel;
        Motor rightWheel;
        const int8_t pwm = 40;
        
};
