#include "Motor.h"
#include "define.h"

using namespace ev3api;

class Measure {
public:
  Measure();
  void Distance_init();
  void DistanceRight_init();
  void DistanceLeft_init();
  void Distance_update();
  float Distance_getDistance();
  float Distance_getDistance4msLeft();
  float Distance_getDistance4msRight();
  void run();
private:
  Motor leftWheel;
  Motor rightWheel;
  const int8_t pwm = (Motor::PWM_MAX)/motorDivide ;
};
