#include "Motor.h"       // <1>
#include "ColorSensor.h" // <2>
#include "define.h"

#define COLOR 0
#define BRIGHTNESS 1

using namespace ev3api;  // <4>



class Tracer {  // <1>
public:
  Tracer();
  void run(int state);       // <2>
  void init();
  void terminate();

private:
  Motor leftWheel;
  Motor rightWheel;
  ColorSensor colorSensor; // <3>

  /* カラーセンサの輝度設定 */
  const int8_t mThreshold = 35;
  const int8_t pwm = 30;

  /* PID制御のためのパラメータ関数 */
  const float valDeltaT = 0.01;
  const float valKp = 0.49;
  const float valKi = 0.0; //0.001
  const float valKd = 0.92; //0.92
  float get_val_pid();
  float calc_prop_value();
  float calc_integral_value();
  float calc_differential_value();
  void trace_run();
  int16_t get_val_sensor(int sensor_type);
};
