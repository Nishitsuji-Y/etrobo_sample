#include "Tracer.h" // <1>
#include "Turn.h"

Turn turn;

Tracer::Tracer():
  leftWheel(PORT_C), rightWheel(PORT_B), colorSensor(PORT_2) { // <2>
  }

void Tracer::init() {
  //なし
}

void Tracer::terminate() {
  leftWheel.stop();  // <1>
  rightWheel.stop();
}

void Tracer::run(int state) {
  trace_run();
    // switch (state)
    // {
    // case TRACE://トレース走行
    //   /* code */
    //   trace_run();
    //   break;
    
    // case TURNLEFT://90度左回転
    //   turn.rotateLeft(); 
    //   break;

    // case STRAIGHT://直進走行
    //   leftWheel.setPWM(pwm);
    //   rightWheel.setPWM(pwm);
    //   break;

    // case STOP://停止
    //   leftWheel.setPWM(0);
    //   rightWheel.setPWM(0);
    //   break;
    // }
}

void Tracer::trace_run(){
  /* トレース走行 */
  // float turn = get_val_pid();
  float turn = calc_prop_value() + calc_integral_value() + calc_differential_value();
  // printf("制御量： %f\n", turn);
  // FILE * fp1 = fopen("/home/irie-raspi/work/RasPike/sdk/workspace/log.csv", "a");
  // fprintf(fp1, "%f\n",turn);
  // fclose(fp1);
  int val_pwm_left = pwm - turn;
  int val_pwm_right = pwm + turn;
  leftWheel.setPWM(val_pwm_left);
  rightWheel.setPWM(val_pwm_right);
  // printf("left_val: %d  right_val: %d\n", val_pwm_left, val_pwm_right);
}

float val_diff[2] = {0.0 ,0.0};
float val_diff_integral = 0.0; 
float Tracer::get_val_pid(){
  const int target = mThreshold;
  const int val_sensor_green = get_val_sensor(BRIGHTNESS);

  val_diff[0] = val_diff[1];
  val_diff[1] = val_sensor_green - target;

  val_diff_integral += (val_diff[0] + val_diff[1]) / 2.0 * valDeltaT;

  float calc_prop = valKp * val_diff[1];
  float calc_integral = valKi * val_diff_integral;
  float calc_differential = valKd * (val_diff[0] + val_diff[1]) / valDeltaT;
  printf("sensor_val: %d  prop: %f  integral: %f differential: %f\n",val_sensor_green ,calc_prop, calc_integral, calc_differential);
  return (calc_prop + calc_integral + calc_differential);
}

float Tracer::calc_prop_value(){
  // fprintf(bt, "%d\r\n", colorSensor.getBrightness());
  printf("brightness: %d\n", colorSensor.getBrightness());
  FILE * fp1 = fopen("/home/irie-raspi/work/RasPike/sdk/workspace/log.csv", "a");
  fprintf(fp1, "%d\n",colorSensor.getBrightness());
  fclose(fp1);
  const int target = mThreshold;
  const int bias = 0;
  int diff = colorSensor.getBrightness() - target;
  return(valKp * diff + bias);
}

// float integralArray[10] = {mThreshold,mThreshold,mThreshold,mThreshold,mThreshold,mThreshold,mThreshold,mThreshold,mThreshold,mThreshold}; 
// int inteArrNum = 0;
int diff_integral = 0;

float Tracer::calc_integral_value(){
  const int target = mThreshold;
  diff_integral += colorSensor.getBrightness() - target;
  // integralArray[inteArrNum] = diff;
  // for(int i=0;i<integralArray.Length;i++){

  // }
  // inteArrNum++;
  return(valKi*diff_integral);
}

int old_diff = 0;
float Tracer::calc_differential_value(){
  const int target = mThreshold;
  int diff_differential = colorSensor.getBrightness() - target;
  int diff = diff_differential - old_diff;
  old_diff = diff_differential;
  return(valKd*diff);
}

int16_t Tracer::get_val_sensor(int sensor_type){

  if (sensor_type == COLOR){
    rgb_raw_t valRawRGB;
    colorSensor.getRawColor(valRawRGB);
    return valRawRGB.g;
  }else if(sensor_type == BRIGHTNESS){
    return colorSensor.getBrightness();
  }else{
    return 0;
  }
}