#include "Measure.h"
//#include "math.h"

/*Distance系*/
// #define TIRE_DIAMETER 100.0       //タイヤ直径(100mm)
// #define PI 3.1415 //円周率

static float distance = 0.0;        //走行距離
static float distance4msL;          //左タイヤの4ms間の走行距離
static float distance4msR;          //右タイヤの4ms間の走行距離
static float pre_angleL,pre_angleR; //左右モータ回転角度の過去値

/* 初期化関数*/

Measure::Measure():
  leftWheel(PORT_C), rightWheel(PORT_B){
  }

void Measure::Distance_init(){
  //各変数の値の初期化
  distance = 0.0;
  distance4msL = 0.0;
  distance4msR = 0.0;
  //モータ角度の過去値に現在値を代入
  pre_angleL = leftWheel.getCount();
  pre_angleR = rightWheel.getCount();
}

void Measure::DistanceLeft_init(){
  distance4msL = 0.0;
}
void Measure::DistanceRight_init(){
  distance4msR = 0.0;
}

/* 距離更新(4ms間の移動距離を毎回加算している) */
void Measure::Distance_update(){
  float cur_angreL = leftWheel.getCount();  //左モータ回転角度の現在値
  float cur_angreR = rightWheel.getCount(); //右モータ回転角度の現在値
  float distanve4ms = 0.0;                              //4msの距離

  //4ms間の走行距離 = ((円周率×タイヤの直径)/360*(モータ角度過去値 - モータ角度現在値))
  distance4msL = ((PI * TIRE_DIAMETER)/360.0)*(cur_angreL-pre_angleL); //4ms間の左モータ距離
  distance4msR = ((PI * TIRE_DIAMETER)/360.0)*(cur_angreR-pre_angleR); //4ms間の右モータ距離
  distanve4ms = (distance4msL+distance4msR)/2.0;                       //左右タイヤの走行距離を足して割る
  distance += distanve4ms;

  //モータの回転角度の過去値を更新
  pre_angleL = cur_angreL;
  pre_angleR = cur_angreR;
}

/* 走行距離を取得 */
float Measure::Distance_getDistance(){
  return distance;
}

/* 左タイヤの4ms間の距離を取得 */
float Measure::Distance_getDistance4msLeft(){
  return distance4msL;
}

/* 右タイヤの4ms間の距離を取得 */
float Measure::Distance_getDistance4msRight(){
  return distance4msR;
}

/* run */
void Measure::run(){
  /*計測器初期化*/
  Distance_init();
  while (1)
  {
    /* code */
    /*距離系、更新 */
    Distance_update();
    //左右車輪駆動
    leftWheel.setPWM(pwm);
    rightWheel.setPWM(pwm);
    //400mm以上前進したら、停止
    if(Distance_getDistance() > 400.0){
      leftWheel.setPWM(0);
      rightWheel.setPWM(0);
    }  
  }
}

/*Distance系（終わり）*/