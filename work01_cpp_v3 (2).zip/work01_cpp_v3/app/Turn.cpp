#include "Turn.h"
#include "define.h"

Turn::Turn():
  leftWheel(PORT_C), rightWheel(PORT_B){
}


void Turn::rotateLeft(){
  leftWheel.setPWM(pwm);
  rightWheel.setPWM(-pwm);
}

void Turn::rotateRight(){
  leftWheel.setPWM(-pwm);
  rightWheel.setPWM(pwm);
}

