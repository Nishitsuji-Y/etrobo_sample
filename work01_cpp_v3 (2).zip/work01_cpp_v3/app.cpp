#include "app.h" // <1>
#include "Tracer.h" // <2>
#include "Clock.h"  // <3>
#include "Measure.h"
#include "define.h"

using namespace ev3api;

Tracer tracer;  // <4>
Clock clock;    // <5>
Measure measure;

int state = TRACE;
int distance = 0;
float distanceRotate = 0.0;
int phase = 0;

void tracer_task(intptr_t exinf) { // <1>
  tracer.run(state); // <2>
  ext_tsk();
}

void measure_cyc(intptr_t exinf) {
  act_tsk(MEASURE_TASK);
}

void measure_task(intptr_t exinf) {
  measure.Distance_update();
  distance = measure.Distance_getDistance();
  // printf("distance: %d\n", distance);
  //STATE0:通常走行
  if(distance <= STATE0_DISTANCE){
    state = TRACE;
  }else if(phase == 0 && distanceRotate<TREAD_DIAMETER*PI/4.0){
    state = TURNLEFT;
    distanceRotate+=measure.Distance_getDistance4msLeft();
  //STATE2:直進
  }else if(distance<=STATE10_DISTANCE){
    state = STRAIGHT;
    phase = 1;
    distanceRotate = 0.0;
  }else if(phase == 1 && distanceRotate<TREAD_DIAMETER*PI/4.0){
    state = TURNLEFT;
    distanceRotate+=measure.Distance_getDistance4msLeft();
  //停止
  }else{
    state = STOP;
  }
  
  ext_tsk();
}

void main_task(intptr_t unused) { // <1>
  const uint32_t duration = 10*1000; // <2>

  tracer.init(); // <3>
  sta_cyc(TRACER_CYC); // <4>
  sta_cyc(MEASURE_CYC);
  
  while (!ev3_button_is_pressed(LEFT_BUTTON)) { // <1>
      clock.sleep(duration);   // <2>
  }

  stp_cyc(TRACER_CYC); // <3>
  stp_cyc(MEASURE_CYC); 
  tracer.terminate(); // <4>
  ext_tsk(); // <5>
}

